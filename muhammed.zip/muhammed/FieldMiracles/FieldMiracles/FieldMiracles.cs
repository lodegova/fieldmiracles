﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FieldMiracles
{
    public class FMException : Exception
    {
        public FMException(string message)
            : base(message)
        { }
    }

    public class FieldMiracles
    {

        private string originalWord;

        private char[] hidenWord;

        public FieldMiracles()
        {
            originalWord = "экскаватор";
            hidenWord = Enumerable.Repeat('*', originalWord.Length).ToArray();
        }
 
        public void openCharIfExist(char c)
        {
            try
            {
                for (int i = 0; i < originalWord.Length; i++)
                {
                    if (originalWord[i] == c & hidenWord[i] == c)
                        throw new FMException("Буква открыта");

                }
            }
            catch
            {
                throw new FMException("Такой буквы нет");
            }
            
        }
       public bool wordIsOpened(string hidenWord)
        {
            return hidenWord.All(i => i != '*');
            throw new FMException("Все буквы открыты");
        }

    }
}

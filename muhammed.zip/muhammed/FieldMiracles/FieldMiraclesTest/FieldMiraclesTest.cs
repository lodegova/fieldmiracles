﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace FieldMiracles.Test
{
    [TestClass]
    public class FieldMiraclesTest
    {
        static FieldMiracles fieldMiracles = null;

        [ClassInitialize]
        static public void Init(TestContext tc)
        {
            fieldMiracles = new FieldMiracles();
        }

        [TestMethod]
               public void ValidWord_true()
               {
                   var hidenWord = "экскаватор";

                   var result = fieldMiracles.wordIsOpened(hidenWord);
                   Assert.IsTrue(result);
               }

        [TestMethod]
        public void ValidWord_true1()
        {
            var hidenWord = "****ава*ор";

            var result = fieldMiracles.wordIsOpened(hidenWord);
            Assert.IsTrue(result);
        }
    }
}
